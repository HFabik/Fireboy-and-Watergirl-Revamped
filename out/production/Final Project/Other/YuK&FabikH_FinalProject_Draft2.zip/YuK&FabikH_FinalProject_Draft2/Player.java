public class Player
{
    protected int x, y, vx = 0, vy = 0; //x, position, y position, x velocity, y velocity
    protected static int diameter = 20;
    protected boolean dirRight = true; //is true if player is going right
    protected int health = 100;
	protected HealthBar hb;
    private Gun gun;

    Player(int xPos, int yPos)
    {
        x = xPos;
        y = yPos;
        gun = new Gun(20, 250, 10);
		hb = new HealthBar(x+diameter/2-HealthBar.LENGTH/2,y-4,100);
    }

    //accessors
    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public int getVx()
    {
        return vx;
    }

    public int getVy()
    {
        return vy;
    }

    public int getDiameter()
    {
        return diameter;
    }

    public int getHealth()
    {
        return health;
    }

    public Gun getGun()
    {
        return gun;
    }

    public boolean getDirRight()
    {
        return dirRight;
    }
	public HealthBar getHBar()
	{
        return hb;
    }

    //modifiers
    public void setX(int xPos)
    {
        x = xPos;
    }

    public void setY(int yPos)
    {
        y = yPos;
    }

    public void setVx(int xVel)
    {
        vx = xVel;
    }

    public void setVy(int yVel)
    {
        vy = yVel;
    }
	
	public void setGun (Gun g)
	{
		gun = g;
	}

    public void setGunBulletInRange(int i, boolean inR)
    {
        gun.setBulletInRange(i, inR);
    }

    public void decreaseHealth(int decrement)
    {
        health -= decrement;
    }

    public void moveX(TheGame game)
    {
        //FOR X
        //x direction is reversed if player is moving towards a wall
        if (x < 20 && vx < 0)
        {
            vx *= -1;
        }
        if (x > 780 && vx > 0)
        {
            vx *= -1;
        }
        //x is moved by vx
        x += vx;
        //if player is travelling left
        if (vx > 0)
        {
            //if player is on a platform, friction takes effect
            if (game.onPlatform(this))
            {
                vx -= TheGame.getAx(); //slowed down
            }
            //updating direction booleans
            dirRight = true;
            gun.setDir(true);
        }//if player is travelling right
        else if (vx < 0)
        {
            //updating direction booleans
            dirRight = false;
            gun.setDir(false);
        }
		hb.setX(x+diameter/2-HealthBar.LENGTH/2);
    }

    public void moveY(TheGame game, int top)
    {
        //FOR Y
		//y direction is reversed if player hits the bottom of a platform
        if (y <= 5 && vy < 0)
        {
            vy *= -1;
        }
        //if player is on platform and would move down, do not move down
        if (game.onPlatform(this) && vy > 0)
        {
            vy = 0;
        }
        //y is moved by vy
        y += vy;
        //vy is always incremented by vertical acceleration
        vy += TheGame.getAy();

        //gun is moved along with player
        moveGun();
		hb.setY(y-4);
    }

    public void moveGun()
    {
        //setting x (direction of gun affects drawing coordinates)
        if (dirRight)
        {
            gun.setX(x + diameter);
        } else
        {
            gun.setX(x - gun.getL() + 1);
        }
        //setting y
        gun.setY(y + diameter / 2);
    }

    public void isDamaged(Enemy e)
    {
        int ex = e.getX();
        int ey = e.getY();
        if (x > ex - 5 && x < ex + 5 && y > ey - 5 && y < ey + 5)
        {
            health -= e.getDmg();
        }
    }

	public void isDamaged(Lake l){
        int lx = l.getX();
        int ly = l.getY();
		int px = x + diameter / 2;
		int py = y + diameter; 
        if(px >= lx && px <=lx+l.getL() && py == ly){
            decreaseHealth(l.getDmg());
        }
    }
	
    public boolean checkIfAlive()
    {
        return (health > 0);
    }
}
