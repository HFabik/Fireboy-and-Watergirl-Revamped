import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.event.*;

//this class contains all the pages necessary (game, menu, settings)
public class Cards extends JFrame implements ActionListener
{
    //cards displays pages using CardLayout
    private JPanel cards, menu, gOver, youWin;

    //the game (extends JPanel)
    private TheGame game = null;

    //JButtons for menu
    private JButton play, settings, credits;
    //new CardLayout
    private CardLayout cardLayout;
    private ImageIcon go, death, win, menuBG;
    private Timer t;
    private JLabel gol, winL; //deathl

    private static final String MENU_CARD = "menu";
    private static final String GAMEOVER_CARD = "gameover";
    private static final String GAME_CARD = "game";
    private static final String WIN_CARD = "win";

    public Cards()
    {
        //formatting the JFrame
        setSize(800, 500);
        setTitle("Fireboy and watergirl but it is actually geometry dash but it is actually surviv.io");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //creating JPanels
		menuBG = new ImageIcon ("another cat.jpg");
        menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.PAGE_AXIS));
        gOver = new JPanel();
        youWin = new JPanel();

        //creating buttons for menu
        play = addButton("Play!", menu, 150);
        settings = addButton("Settings", menu, 20);
        credits = addButton("Credits", menu, 20);

        //sets up game over screen
        go = new ImageIcon("GameOver.png");
        gol = new JLabel(go);
        gOver.add(gol);

        //sets up winning screen
        win = new ImageIcon("YouWin.png");
        winL = new JLabel(win);
        youWin.add(winL);

        //setting up cardLayout
        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);
        cards.add(menu, MENU_CARD);
        cards.add(gOver, GAMEOVER_CARD);
        cards.add(youWin, WIN_CARD);
        //adding cards
        getContentPane().add(cards);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
        //pressing play takes the player to the game JPanel
        if (e.getSource() == play)
        {
            executeInSwingThread(this::startGame);
        } else if (e.getSource() == t)
        {
            if (game != null && !game.getPlayer().checkIfAlive())
            {
                t.stop(); // Prevent repeated events from the timer
                executeInSwingThread(this::doGameOver);
            } else if (game.getEndSq().onEnd(game.getPlayer()))
            {
                t.stop();
                executeInSwingThread(this::showWin);
            }
        }
    }
	
    private JButton addButton(String text, Container c, int height)
    {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.addActionListener(this);
        c.add(Box.createRigidArea(new Dimension(0, height)));
        c.add(button);
        return button;
    }

    private void doGameOver()
    {
        stopGame();
        cardLayout.show(cards, GAMEOVER_CARD);
        unfocus();
        gOver.setFocusable(true);
        timeRestart();
    }

    private void showWin()
    {
        stopGame();
        cardLayout.show(cards, WIN_CARD);
        unfocus();
        youWin.setFocusable(true);
        timeRestart();
    }

    private void timeRestart()
    {
        Timer timer = new Timer(2000, e -> executeInSwingThread(this::restartGame));
        timer.setRepeats(false);
        timer.start();
    }

    private void showMenu()
    {

        cardLayout.show(cards, "menu");
        unfocus();
        menu.setFocusable(true);
		repaint();
    }

    private void restartGame()
    {

        SwingUtilities.invokeLater(this::showMenu);
    }

    private void stopGame()
    {

        if (game != null)
        {
            t.stop();
            game.discard(this);
            cardLayout.removeLayoutComponent(game);
            cards.remove(game);
            game = null;
        }
    }

    private void startGame()
    {

        stopGame();

        game = new TheGame(this);
        game.setLayout(null);

        //death
        /*death = new ImageIcon( "animated-fireworks-image-0087.gif" );
        deathl = new JLabel( death );
        game.add( deathl );*/

        cards.add(game, "game");
        cardLayout.show(cards, "game");
        unfocus();
        game.setFocusable(true);
        t = new Timer(50, this);
        t.start();
    }

    private void unfocus()
    {
        menu.setFocusable(false);
        play.setFocusable(false);
        settings.setFocusable(false);
        gOver.setFocusable(false);
        if (game != null)
        {
            game.setFocusable(false);
        }
    }

    private void executeInSwingThread(Runnable runnable)
    {
        if (SwingUtilities.isEventDispatchThread())
        {
            runnable.run();
        } else
        {
            try
            {
                SwingUtilities.invokeAndWait(runnable);
            } catch (Exception ignored)
            {
            }
        }
    }

    public static void main(String[] args)
    {
        //run
        Cards c = new Cards();
        c.showMenu();
    }
}
