public class HealthBar {
    static final int LENGTH = 25;
    static final int WIDTH = 5;
    int x;
    int y;
    int health;
    public HealthBar(int xPos, int yPos,int h){
        health = h/4;
        x = xPos;
        y = yPos;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public int getHealth(){
        return health;
    }
    public void setX(int xPos){
        x = xPos;
    }
    public void setY(int yPos){
        y = yPos;
    }
    public void setHealth(int h){
        health = h/4;
    }
}
