public class Lake extends Platform{
	int dmg;
	Lake(int xPos,int yPos,int length){
		super(xPos,yPos,length);
		h = 5;
		dmg = 7;
	}
	public int getDmg(){
		return dmg;
	}
}