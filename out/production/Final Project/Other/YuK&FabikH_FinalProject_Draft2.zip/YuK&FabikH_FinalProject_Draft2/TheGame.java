import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TheGame extends JPanel implements ActionListener
{
    private Door[] d;
    private Timer t = new Timer(40, this);
    private Player p;
    private Platform[] pf;
    private int nd = 1, npf = 9, ne = 1, nl = 2;
    private int place = 0;
    private Enemy[] enemies;
    private final static int ax = 1, ay = 2; //horizontal acceleration due to friction (scalar), vertical acceleration due to gravity (scalar)
    private EndSquare ens;
    private KeyListener keyListener;
    private ImageIcon end, backg;
	private Lake [] lakes;

    public TheGame(JFrame frame)
    {
        //sets Background
        backg = new ImageIcon("Background.png");
        //sets array of doors
        d = new Door[nd];
        int x = 400;
        for (int i = 0; i < nd; i++)
        {
            d[i] = new Door(x, 395);
            x += 150;
        }

        //sets player
        p = new Player(10, 400);
        //sets enemies
        enemies = new Enemy[ne];
        enemies[0] = new Enemy(300, 325);

        //sets array of platforms
        pf = new Platform[npf];
		makePlatforms();
		
        //sets end square
        ens = new EndSquare(0, 25);
        //sets ImageIcon for end square
        end = new ImageIcon("EndSquare.png");
		//sets lakes 
		lakes = new Lake[nl];
		lakes[0] = new Lake(60,420,60);
		lakes[1] = new Lake(60,345,30);
        //sets KeyListener
        keyListener = new KeyListener()
        {
            public void keyTyped(KeyEvent e)
            {
				char k = e.getKeyChar();
                if (k == 'd')
                {
					int close = findDoor();
                    if (close <= d[place].getSwitch().getRange())
                    {
                        d[place] = open(d[place]);
                        repaint();
                    }
                } else if (k == 'w')
                {
                    if (onPlatform(p))
                    {
                        p.setVy(-17);
                    }
                }
				else if(k == 'r')
				{
					Gun temp = p.getGun();
					temp.reload();
					p.setGun(temp);
				}else if (k == 'f')
                {
                    p.getGun().fire();
                }
            }

            public void keyPressed(KeyEvent e)
            {
            }

            public void keyReleased(KeyEvent e)
            {
            }
        };


        frame.setFocusable(true);
        frame.addKeyListener(keyListener);
    }

    public static int getAx()
    {
        return ax;
    }

    public static int getAy()
    {
        return ay;
    }

    public Player getPlayer()
    {
        return p;
    }

    public EndSquare getEndSq()
    {
        return ens;
    }

    public void discard(JFrame frame)
    {
        frame.removeKeyListener(keyListener);
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        //paints background
        g.drawImage(backg.getImage(), 0, 0, null);
        //paints the end square
        g.drawImage(end.getImage(), ens.getX(), ens.getY(), null);
        //paint player
        g.setColor(Color.PINK);
        g.fillOval(p.getX(), p.getY(), p.getDiameter(), p.getDiameter());
        //paints gun
        g.setColor(Color.BLACK);
        g.fillRect(p.getGun().getX(), p.getGun().getY(), p.getGun().getL(), p.getGun().getW());
		//paints health bar
		 drawHBar (p.getHBar(), g);
        //paint platforms
        g.setColor(Color.BLACK);
        for (int i = 0; i < npf; i++)
        {
            g.fillRect(pf[i].getX(), pf[i].getY(), pf[i].getL(), pf[i].getH());
        }
        //paint doors
        for (int i = 0; i < nd; i++)
        {
            if (d[i].getSwitch().getState())
            {
                g.setColor(Color.CYAN);
                g.fillRect(d[i].getX(), d[i].getY(), d[i].getWid(), d[i].getLen());
            }
            g.setColor(d[i].getSwitch().getCol());
            g.fillOval(d[i].getSwitch().getX(), d[i].getSwitch().getY(), d[i].getSwitch().getSize(), d[i].getSwitch().getSize());
        }
		//paints lakes
		g.setColor(Color.MAGENTA);
		for(int i = 0; i < lakes.length; i++)
		{	
			g.fillRect(lakes[i].getX(),lakes[i].getY(),lakes[i].getL(),lakes[i].getH());		
		}
        //paint eneimes
        g.setColor(Color.BLUE);
        for (int i = 0; i < ne; i++)
        {
            Enemy temp = enemies[i];
            if (temp.checkIfAlive())
            {
                g.fillOval(temp.getX(), temp.getY(), temp.getDiameter(), temp.getDiameter());
				//paints enemies' health bar
				drawHBar(temp.getHBar(), g);
            }
        }
        //drawing bullets
		g.setColor(Color.BLACK);
        for (int i = 0; i < p.getGun().getNumBullets(); i++)
        {
            if (p.getGun().getBullet(i).getInRange())
            {
                Bullet bullet = p.getGun().getBullet(i);
                if (bullet.getInRange())
                {
                    g.fillOval(bullet.getX(), bullet.getY(), Bullet.getDiam(), Bullet.getDiam());
                }
            }
        }
        t.start();
    }
	private void drawHBar(HealthBar h, Graphics g)
	{
		//drawing healthbar
		g.setColor(Color.RED);
        g.fillRect(h.getX(),h.getY(),HealthBar.LENGTH,HealthBar.WIDTH);
        g.setColor(Color.GREEN);
        g.fillRect(h.getX(),h.getY(),h.getHealth(),HealthBar.WIDTH);
	}

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == t)
        {
			checkBounds();
            if (p.checkIfAlive())
            {
                //check if enemies are alive
                for (int i = 0; i < ne; i++)
                {
                    if (enemies[i].checkIfAlive())
                    {
                        enemies[i].pace();
                        enemies[i].moveX(this);
						enemies[i].getHBar().setHealth(enemies[i].getHealth());
                        p.isDamaged(enemies[i]);
                        for (int j = 0; j < p.getGun().getNumBullets(); j++)
                        {
                            if (enemies[i].isShot(p.getGun().getBullet(j)))
                            {
                                p.setGunBulletInRange(j, false);
                                enemies[i].decreaseHealth(p.getGun().getDmg());
                            }
                        }
                    }
                }
                //each of the fired bullets is moved
                for (int i = 0; i < p.getGun().getNumBullets(); i++)
                {
                    p.getGun().getBullet(i).move();
                }
                //check doors
                if (p.getDirRight())
                {
                    p.setVx(10);
                } else
                {
                    p.setVx(-10);
                }
                int dis = findDoor();
                if (dis <= p.getDiameter() && d[place].getSwitch().getState())
                {
                    p.decreaseHealth(p.getHealth());
                }
				//check for damage from lakes
				for(int i = 0; i < 2; i++)
				{
					p.isDamaged(lakes[i]);
				}
                //move player and repaint
                p.moveX(this);
                p.moveY(this, findPfAbove());
				//sets health
				p.getHBar().setHealth(p.getHealth());
                repaint();
            }
        }
    }

	private int findPfAbove () //does not work
	{
		int py = p.getY();
		int top = 500;
		for (int i = py; i > py - 75; i--)
		{
			for (int j = 0; j < npf; j++)
			{
				if (i == pf[j].getY())
				{
					top = i - pf[j].getH();
					return top;
				}
			}
		}
		return top;
	}
	
    private Door open(Door dn)
    {
        dn.getSwitch().setState(false);
        return dn;
    }

    public boolean onPlatform(Player actor)
    { //this methods checks if player is on platform (within 10px)
        boolean onPlatform = false;
        int range = 7; //vertical range within which player is considered to be on the platform
        for (int i = 0; i < pf.length; i++)
        { //for each platform
            //booleans for if player x and y are on platform or not
            boolean xMatch = false;
            boolean yMatch = false;
            //getting positions of player
            int playerY = actor.getY() + actor.getDiameter();
            int playerX = actor.getX();
            //getting positions of platform
            int platX = pf[i].getX();
            int platY = pf[i].getY();
            //handling exception where playerX is past left edge but the player is not fully off platform
            if (playerX < platX && (playerX + actor.getDiameter()) > platX)
            {
                playerX += actor.getDiameter();
            }
            //if playerY == platY (+-10) OR the player would pass the platform on the next animation
            if ((playerY <= platY + range && playerY >= platY - range) || (playerY < platY && playerY + p.getVy() > platY))
            {
                yMatch = true;
            }
            //if playerX is between the left and right ends of the platform
            if (playerX >= platX && playerX <= (platX + pf[i].getL()))
            {
                xMatch = true;
            }
            //player is on platform for both x and y
            if (xMatch && yMatch)
            {
                onPlatform = true;
                //adjusting (in case y fell within the +- 10)
                actor.setY(platY - actor.getDiameter());
            }
        }
        return onPlatform;
    }

    private int findDoor()
    {
        int px = p.getX();
        int closest = 800, dis;
        place = 0;
        for (int i = 0; i < nd; i++)
        {
            dis = Math.abs(d[i].getX() - px);
            if (dis < closest)
            {
                closest = dis;
                place = i;
            }
        }
        return closest;
    }

    public void checkBounds()
    {
        if (p.getY() >= 500)
        {
            p.decreaseHealth(p.getHealth());
        }
    }
	
	private void makePlatforms()
	{
		pf[0] = new Platform (0, 420, 500);
		pf[1] = new Platform (550, 420, 250);
        pf[2] = new Platform (0, 345, 725);
		pf[3] = new Platform (75, 270, 300);
		pf[4] = new Platform (425, 270, 350);
		pf[5] = new Platform (300, 195, 450);
		pf[6] = new Platform (0, 195, 250);
		pf[7] = new Platform (75, 120, 725);
		pf[8] = new Platform (0, 45, 725);
	}
}
