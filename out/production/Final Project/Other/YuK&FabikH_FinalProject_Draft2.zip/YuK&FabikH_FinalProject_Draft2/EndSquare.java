public class EndSquare extends Platform
{
    // x, y, l, h
    public EndSquare(int x, int y)
    {
        super(x, y, 20);
        h = 20;
    }

    public boolean onEnd(Player p)
    {
        return (p.getX() + p.getDiameter() / 2 <= x + 20 && p.getX() + p.getDiameter() / 2 >= x) && (p.getY() + p.getDiameter() / 2 >= y && p.getY() + p.getDiameter() / 2 <= y + 20);
    }
}