import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

//this class contains all the pages necessary (game, menu, settings)
public class Cards extends JFrame implements ActionListener
{
    //cards displays pages using CardLayout
    private JPanel cards, menu, gOver;

    //the game (extends JPanel)
    private TheGame game = null;

    //JButtons for menu
    private JButton play, settings, credits;
    //new CardLayout
    private CardLayout cardLayout;
    private ImageIcon go, death;
    private Timer t;
    private JLabel gol, deathl;

    private static final String MENU_CARD = "menu";
    private static final String GAMEOVER_CARD = "gameover";
    private static final String GEME_CARD = "game";

    public Cards()
    {
        //formatting the JFrame
        setSize( 800, 500 );
        setTitle( "card layout, wow!" );
        setResizable( false );

        //creating JPanels
        menu = new JPanel();
        gOver = new JPanel();

        //creating buttons for menu
        play = new JButton( "play!" );
        settings = new JButton( "settings" );
        credits = new JButton( "credits" );

        //adding ActionListener
        play.addActionListener( this );
        settings.addActionListener( this );
        credits.addActionListener( this );

        //adding buttons
        menu.add( play );
        menu.add( settings );
        menu.add( credits );

        //sets up game over screen
        go = new ImageIcon( "GameOver.png" );
        gol = new JLabel( go );
        gOver.add( gol );

        //setting up cardLayout
        cardLayout = new CardLayout();
        cards = new JPanel( cardLayout );
        cards.add( menu, MENU_CARD );
        cards.add( gOver, GAMEOVER_CARD );
        //adding cards
        getContentPane().add( cards );
        setVisible( true );
    }

    public void actionPerformed( ActionEvent e )
    {
        //pressing play takes the player to the game JPanel
        if( e.getSource() == play )
        {
            executeInSwingThread( this::startGame );
        }
        else if( e.getSource() == t )
        {
            if( game != null && game.outOfBounds() )
            {
                t.stop(); // Prevent repeated events from the timer
                executeInSwingThread( this::doGameOver );
            }
        }
    }

    private void doGameOver()
    {
        stopGame();
        
        //System.out.println( "dogameover" );
        cardLayout.show( cards, GAMEOVER_CARD );
        unfocus();
        gOver.setFocusable( true );

        Timer timer = new Timer( 2000, e -> executeInSwingThread( this::restartGame ) );
        timer.setRepeats( false );
        timer.start();
    }

    private void showMenu()
    {
        
        cardLayout.show( cards, "menu" );
        unfocus();
        menu.setFocusable( true );
    }

    private void restartGame()
    {
       
        SwingUtilities.invokeLater( this::showMenu );
    }

    private void stopGame()
    {
        
        if( game != null )
        {
            t.stop();
            game.discard( this );
            cardLayout.removeLayoutComponent( game );
            cards.remove( game );
            game = null;
        }
    }

    private void startGame()
    {
        
        stopGame();

        game = new TheGame( this );
        game.setLayout( null );

        //death
        death = new ImageIcon( "animated-fireworks-image-0087.gif" );
        deathl = new JLabel( death );
        game.add( deathl );

        cards.add( game, "game" );
        cardLayout.show( cards, "game" );
        unfocus();
        game.setFocusable( true );
        t = new Timer( 50, this );
        t.start();
    }

    private void unfocus()
    {
        menu.setFocusable( false );
        play.setFocusable( false );
        settings.setFocusable( false );
        gOver.setFocusable( false );
        if( game != null )
        {
            game.setFocusable( false );
        }
    }

    private void executeInSwingThread( Runnable runnable )
    {
        if( SwingUtilities.isEventDispatchThread() )
        {
            runnable.run();
        }
        else
        {
            try
            {
                SwingUtilities.invokeAndWait( runnable );
            }
            catch( Exception ignored )
            {
            }
        }
    }

    public static void main( String[] args )
    {
        //run
        Cards c = new Cards();
        c.showMenu();
    }
}
