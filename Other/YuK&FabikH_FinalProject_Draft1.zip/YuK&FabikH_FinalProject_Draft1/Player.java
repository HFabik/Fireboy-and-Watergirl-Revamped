public class Player 
{
    protected int x, y, vx = 0, vy = 0; //x, position, y position, x velocity, y velocity
    protected static int diameter = 20;
    protected boolean dirRight = true; //is true if player is going right
    protected int health = 100;
    private Gun gun;

    Player(int xPos,int yPos)
	{
        x = xPos;
        y = yPos;
        gun = new Gun(20, 200,10);
    }
	
    //accessors
    public int getX()
	{
        return x;
    }
    public int getY()
	{
        return y;
    }
    public int getVx()
	{
        return vx;
    }
    public int getVy()
	{
        return vy;
    }
    public int getDiameter()
	{
        return diameter;
    }
    public int getHealth()
	{
        return health;
    }
    public Gun getGun()
	{
        return gun;
    }

    //modifiers
    public void setX(int xPos)
	{
        x = xPos;
    }
    public void setY(int yPos)
	{
        y = yPos;
    }
    public void setVx(int xVel)
	{
        vx = xVel;
    }
    public void setVy(int yVel)
	{
        vy = yVel;
    }
    public void setGunBulletInRange(int i,boolean inR)
	{
        gun.setBulletInRange(i,inR);
    }
    public void decreaseHealth(int decrement){health -= decrement;}

    public void move(TheGame game)
	{
        //FOR X
        //x direction is reversed if player is moving towards a wall
        if(x < 20 && vx < 0)
		{
            vx *= -1;
        }
        if (x > 780 && vx > 0)
		{
            vx *= -1;
        }
        //x is moved by vx
        x += vx;
        //if player is travelling left
        if(vx > 0)
		{
            //if player is on a platform, friction takes effect
            if(game.onPlatform(this))
			{
                vx -= TheGame.getAx(); //slowed down
            }
            //updating direction booleans
            dirRight = true;
            gun.setDir(true);
        }//if player is travelling right
        else if (vx < 0)
		{
            //if player is on a platform, friction takes effect
            if(game.onPlatform(this))
			{
                vx += TheGame.getAx(); //slowed down
            }
            //updating direction booleans
            dirRight = false;
            gun.setDir(false);
        }

        //FOR Y
        //if player is on platform and would move down, do not move down
        if(game.onPlatform(this) && vy > 0)
		{
            vy = 0;
        }
        //y is moved by vy
        y += vy;
        //vy is always incremented by vertical acceleration
        vy += TheGame.getAy();

        //gun is moved along with player
        moveGun();
    }
	
    public void moveGun()
	{
        //setting x (direction of gun affects drawing coordinates)
        if(dirRight)
		{
            gun.setX(x + diameter);
        } else 
		{
            gun.setX(x - gun.getL() + 1);
        }
        //setting y
        gun.setY(y + diameter/2);
    }
	
    public void isDamaged(Enemy e)
	{
        int ex = e.getX();
        int ey = e.getY();
        if(x > ex-5 && x < ex+5 && y > ey-5 && y < ey+5)
		{
            health -= e.getDmg();
        }
    }
	
    public boolean checkIfAlive()
	{
        return (health > 0);
    }
}
