import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TheGame extends JPanel implements ActionListener
{
    private Door[] d;
	private Timer t = new Timer(40,this);
	private Player p;
	private Platform[] pf;
	private int nd = 2, npf = 5, ne = 1;
	private JLabel l;
	private int place = 0;
	private Enemy [] enemies;
	private final static int ax = 1, ay = 2; //horizontal acceleration due to friction (scalar), vertical acceleration due to gravity (scalar)
	private KeyListener keyListener;

	public TheGame ( JFrame frame )
    {
		//sets JLabel (testing purposes)
		l = new JLabel("");
		add(l);
		l.setLocation(10, 10);
		
		//sets array of doors
		d = new Door[nd];
		int x = 300;
		for (int i = 0; i < nd; i++ )
		{
			d[i] = new Door (x, 395);
			x += 150;
		}
		
		//sets player
		p = new Player(200,400);
		//sets enemies
		enemies = new Enemy[ne];
        enemies[0] = new Enemy(300, 300);
		
		//sets array of platforms
		pf = new Platform[npf];
		x = 0;
		int y = 420;
		int length = 600;
		for (int i = 0; i<npf; i++)
		{
			pf[i]= new Platform(x, y, length);
			x += 100;
			y -= 75;
			length -= 75;
		}
		
		//sets KeyListener
		keyListener = new KeyListener()
            {
                public void keyTyped(KeyEvent e)
                {
                    char key = e.getKeyChar();
                    int close = findDoor();
                    if (key == 'f')
                    {
                        if (close <= d[place].getSwitch().getRange())
                        {
                            d[place] = open(d[place]);
                            repaint();
                        }
                    }
                    else if (key == 'a')
                    {
                        p.setVx(-10);
                    }
                    else if (key == 'd')
                    {
                        p.setVx(10);
                    }
                    else if (key == 'w')
                    {
                        if(onPlatform(p))
                        {
                            p.setVy(-17);
                        }
                    }
					else if(e.getKeyCode() == KeyEvent.VK_SPACE)
					{
						p.getGun().fire();
					}
                }
                public void keyPressed(KeyEvent e) {}
                public void keyReleased(KeyEvent e) {}
            };


		frame.setFocusable(true);
		frame.addKeyListener( keyListener );
    }

	public static int getAx()
	{
        return ax;
    }
    public static int getAy()
	{
        return ay;
    }
	
    public void discard( JFrame frame )
    {
        frame.removeKeyListener( keyListener );
    }

    public void paintComponent (Graphics g)
    {
        super.paintComponent(g);
		//paint player
		g.setColor(Color.PINK);
		g.fillOval(p.getX(),p.getY(),p.getDiameter(),p.getDiameter());
		//paints gun
		g.setColor(Color.BLACK);
		g.fillRect(p.getGun().getX(),p.getGun().getY(),p.getGun().getL(),p.getGun().getW());
		//paint platforms
		g.setColor(Color.BLACK);
		for (int i = 0; i < npf; i++)
		{
			g.fillRect(pf[i].getX(),pf[i].getY(),pf[i].getL(),pf[i].getH());
		}
		//paint doors
		for (int i = 0; i< nd; i++)
		{
			if (d[i].getSwitch().getState())
			{
				g.setColor(d[i].getCol());
				g.fillRect(d[i].getX(), d[i].getY(), d[i].getWid(), d[i].getLen());
			}
			g.setColor(d[i].getSwitch().getCol());
			g.fillOval(d[i].getSwitch().getX(), d[i].getSwitch().getY(), d[i].getSwitch().getSize(), d[i].getSwitch().getSize());
        }
		//paint eneimes
		g.setColor(Color.BLUE);
		for(int i = 0; i < ne; i++)
		{
            Enemy temp = enemies[i];
            if(temp.checkIfAlive())
			{
                g.fillOval(temp.getX(),temp.getY(),temp.getDiameter(),temp.getDiameter());
            }
        }
        //drawing bullets
        for(int i = 0; i < p.getGun().getNumBullets(); i++)
		{
            if(p.getGun().getBullet(i).getInRange())
			{
                Bullet bullet = p.getGun().getBullet(i);
                if(bullet.getInRange())
				{
                    g.fillOval(bullet.getX(),bullet.getY(),Bullet.getDiam(),Bullet.getDiam());
                }
            }
        }
		t.start();
    }
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == t)
		{
			if(p.checkIfAlive())
			{
				for(int i = 0; i < ne; i++)
				{
					if(enemies[i].checkIfAlive())
					{
						enemies[i].pace();
						enemies[i].move(this);
						p.isDamaged(enemies[i]);
						for(int j = 0; j < p.getGun().getNumBullets(); j++) 
						{
							if (enemies[i].isShot(p.getGun().getBullet(j))) 
							{
                            p.setGunBulletInRange(j,false);
                            enemies[i].decreaseHealth(p.getGun().getDmg());
							}
						}
					}
				}
				//each of the fired bullets is moved
				for(int i = 0; i < p.getGun().getNumBullets(); i++)
				{
					p.getGun().getBullet(i).move();
				}
				int dis = findDoor();
				if (dis > p.getDiameter() || !d[place].getSwitch().getState())
				{
					p.move( this );
				}
				repaint();
				l.setText("player health " + p.getHealth() + " enemy health " + enemies[0].getHealth());
			}
        }
    }
	
    private Door open(Door dn)
    {
        dn.getSwitch().setState(false);
        return dn;
    }
	
	 public boolean onPlatform(Player actor)
	 { //this methods checks if player is on platform (within 10px)
        boolean onPlatform = false;
        int range = 7; //vertical range within which player is considered to be on the platform
        for(int i = 0; i < pf.length; i++)
		{ //for each platform
            //booleans for if player x and y are on platform or not
            boolean xMatch = false;
            boolean yMatch = false;
            //getting positions of player
            int playerY = actor.getY() + actor.getDiameter();
            int playerX = actor.getX();
            //getting positions of platform
            int platX = pf[i].getX();
            int platY = pf[i].getY();
            //handling exception where playerX is past left edge but the player is not fully off platform
            if(playerX < platX && (playerX + actor.getDiameter()) > platX) 
			{
                playerX += actor.getDiameter();
            }
            //if playerY == platY (+-10) OR the player would pass the platform on the next animation
            if((playerY <= platY+range && playerY >= platY-range) || (playerY < platY && playerY+p.getVy() > platY))
			{
                yMatch = true;
            }
            //if playerX is between the left and right ends of the platform
            if(playerX >= platX && playerX <= (platX + pf[i].getL()))
			{
                xMatch = true;
            }
            //player is on platform for both x and y
            if(xMatch && yMatch)
			{
                onPlatform = true;
                //adjusting (in case y fell within the +- 10)
                actor.setY(platY - actor.getDiameter());
            }
        }
        return onPlatform;
    }
	
	private int findDoor ()
	{
		int px = p.getX();
		int closest = 800, dis;
		place = 0;
		for (int i = 0; i < nd; i ++)
		{
			dis = Math.abs(d[i].getX()-px);
			if (dis < closest)
			{
				closest = dis;
				place = i;
			}
		}
		return closest;
	}
	public boolean outOfBounds()
	{
		return ( p.getY() < 0 || p.getY() > 500);
	}
	public Player getPlayer(){ return p; }
}
