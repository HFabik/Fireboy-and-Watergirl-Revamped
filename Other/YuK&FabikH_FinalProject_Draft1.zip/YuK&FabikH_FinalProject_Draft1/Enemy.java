public class Enemy extends Player
{
    private int xTravelled = 0;
    private int range = 100;
    private int dir = 1;
    private int dmg = 5;
    public Enemy(int x, int y)
    {
        super(x,y);
    }
    public int getDmg(){
        return dmg;
    }
    public void pace(){
        if(Math.abs(xTravelled) + 7 <= range){
            vx = 7 * dir;
            xTravelled += vx;
        } else {
            xTravelled = 0;
            dir *= -1;
        }
    }
    public boolean isShot(Bullet b){
        int bx = b.getX();
        int by = b.getY();
        int enemyX = x + diameter/2;
        int enemyY = y + diameter/2;
        boolean isShot = false;
        if(b.getInRange() && (bx > enemyX-8 && bx < enemyX+8) && (by > enemyY-diameter && by < enemyY+diameter)) {
            isShot = true;
        }
        return isShot;
    }
}